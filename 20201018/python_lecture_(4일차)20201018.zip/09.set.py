# 집합 set 1. 겹치지 않고  2. 순서가 없음
# dic0 = {} #dictionary
# dic = {"key":"values"}
# s = set() #set 초기화

set1 = {100, 200, 300, '100', 300}
print(type(set1))
print(set1)
print(dir(set1))

set2 = set()
print(type(set2))

set3 = {"apple"}
set3 = set("apple")
print(set3)

set4 = set("ant")
print(set4)

print(set3 - set4) #차집합
print(set3 | set4) #합집합
print(set3 & set4) #교집합

#추가 add update
set5 = set()
set5.add(100)
set5.add(200)
set5.add(300)
print(set5)
set5.add(200)
print(set5)

set5.update([400, 500, 100])
print(set5)

#삭제 discard remove
set5.discard(100)
print(set5) 

# set5.remove(100)
# print(set5)

#집합 연산자 difference intersection union
set6 = {'a','b','c','d','e'}
set7 = {'a','b','c','f','g'}

set8 = set6.difference(set7)    #de
print(set8)
set8 = set6.intersection(set7)  #abc
print(set8)
set8 = set6.union(set7)         #abcdefg
print(set8)








