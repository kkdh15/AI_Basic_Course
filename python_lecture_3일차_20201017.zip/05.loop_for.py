# 반복문
# for   : 반복 횟수
# for (변수) in range(시작값, 종료값, 증가값):
#   실행문
# print("hello world")
# print("hello world")
# print("hello world")
# print("hello world")
# print("hello world")

for (i) in range(0, 100, 1): # 0 1 2 3 4 5 6 7 8 ... 99
    #print(i)
    pass

for (j) in range(5, -1 ,-1):   # 5 4 3 2 1 0
    print(j, end=' ')
print()

# 1~10 합
sum = 0
for k in range(1,11,1):  # k = 1, 2, 3, 4 ... 10
    print(k, end = " ") 
    sum = sum + k        # sum = 1, 3, 6 ....
print("\nsum = %d" %sum)

# 123부터 ~ 500까지 짝수 모두 더하기
sum = 0
for value in range(123, 501, 1):
    if value % 2 == 0:
        sum += value 
        #print(value, end=" ")
print("sum={}".format(sum))

sum = 0 #변수 초기화
for value in range(124, 501, 2):
        sum += value 
        #print(value, end=" ")
print("sum={}".format(sum))

# 구구단 (2단)
# 2 * 1 = 2
# 2 * 2 = 4 
# ...
# 2 * 9 = 18
dan, i = 2, 1
for i in range(1,10,1):
    print("{0} * {1} = {2}".format(dan,i,dan*i))
print()

# 2 ~ 9단
for dan in range(2,10,1):
    for i in range(1,10,1):
        print("{0} * {1} = {2}"
        .format(dan,i,dan*i))

#=> 2 ~ 9단 * 1 ~ 9
for i in range(1, 10, 1):
    for dan in range(2, 10, 1):      
        print("{0} * {1} = {2}"
        .format(dan, i, dan*i), end='\t')
    print()
print()
for i in range(1, 10, 1):
    for dan in range(2, 10, 1):
        if (i==(dan-1)):
            print("         ", end="\t")
        else :
            print("{0} * {1} = {2}".format(dan, i, dan*i), end="\t")
    print()      

















# while : 반복 조건
