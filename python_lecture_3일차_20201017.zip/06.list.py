# # python 자료형 
# # int float bool 
# a1 = 10
# a2 = 20
# a3 = 30

# # 배열 array 
# # 리스트 list
# a = [10, 20, 30] #a[0] = 10, a[1] = 20, a[2] = 30
# print(type(a))

# for temp in a:
#     print(temp, end=" ")
# print()

# a[1] = 2000

# for i in range(0,3,1):
#     print(a[i], end=" ")

# # 문제 - 4개 값을 가지는 list < 임의값 4개 입력 전체 합을 출력하시오.
# list = [0, 0, 0, 0]
# sum = 0
# for i in range(0,4):
#     list[i] = int(input("Insert value : "))
#     sum += list[i]
# print("전체 합 : {}".format(sum))

# list = []
# sum = 0
# for i in range(0,4):
#     list.append(int(input("Insert value : ")))
#     sum += list[i]
# print("전체 합 : {}".format(sum))

# #초기화(Dynamic array)
# a = []       #list명은 정했지만 저장 갯수 X
# a = [0,0,0]  #list명은 정하고 저장 갯수 3
# a = [0, "yeo", True]

# #슬라이싱(Slicing)
# print(a[0])    # 0
# print(a[0:2])  # 0 yeo
# print(a[-1])   # True
# print(a[:])    # 0 yeo True

# #추가 append(185), insert expend
# a.append(185)
# print(a)
# a.insert(0,"first")  # 0 index "first" 값
# print(a)
# a.insert(1,"second")  # 1 index "second" 값
# print(a)

# #변경 list[index] = 값
# a[3] = 184
# print(a)

# #삭제 del list[index], remove, pop
# del a[0]
# print(a[:])

# #병합 +
# b = ["dongbin", False, 100]
# c = a + b
# print(c,len(c),end="\n") 
# # ['yeo', True, 184, "dongbin", False, 100]

# d = a
# print(d)
# d.append(b)
# print(d,len(d),end="\n") 
# # ['yeo', True, 184, ["dongbin", False, 100]]

# #반복
# d = a * 2
# print(d)

# #검색
# string = "my name is yeo dongbin".split()
# index = string.index("yeo") #11
# count = string.count("m")   #2
# print(index, count)

# 깊은 복사 얇은 복사
alist = [1,2,3,4]
blist = alist #얇은 복사
print(id(alist))
print(id(blist))
print(blist)
alist[3] = 10
print(blist)

