#상속 - 이미 정의된 클래스를 상속받아서 사용하는 방법

class Parent():
    def __init__(self):
        self.a = 10
    
    def run(self):
        print("I am running")

class Child(Parent):
    def __init__(self):
        self.b = 20

# 내부 호출 ####################################################
class Car():
    #class variable
    max_speed = 300
    max_people = 5
    def __init__(self):
        print('Car() 생성자 호출')
    def __str__(self):
        print('나는 자동차 입니다.')
    def run(self):
        print("자동차가 달립니다.")
    def stop(self):
        print("자동차가 멈쉽니다.")
        self.stoplight()
    def stoplight(self):
        print('브레이크등이 켜졌습니다.')

class Hybrid(Car):
    battery_capa = 1000
    battery_km = 300

# 생성자 호출 순서####################################################

class People():
    def __init__(self):
        print("People.__init__()")    

class Athlet(People):
    def __init__(self):
        super().__init__()
        print("Athlet.__init__()")    

class BaseballPlayer(Athlet):
    def __init__(self):
        print("BaseballPlayer.__init__()")    
        super().__init__()

# Override, 다형성 ####################################################
class Animal():
    def sound(self):
        print("동물소리")

class Cat(Animal):
    def sound(self):#Override
        print("야옹")

    def roll(self):
        print('고양이가 구른다.')
    
class Dog(Animal):
    def sound(self):#Override
        print("왈왈")

    def walk(self):
        print("개는 산책중")

class Pig(Animal):
    def sound(self):#Override
        print("꿀꿀")

    def eat(self):
        print("돼지는 먹는중")
    
# if __name__ == "__main__":
#    animal = Animal()
#    cat = Cat()
#    dog = Dog()
#    pig = Pig()
#    animal.sound()
#    #animal.walk()
#    cat.sound()
#    cat.roll()
#    dog.sound()
#    dog.walk()
#    pig.sound()
#    pig.eat()

#    animals = [cat, dog, pig]
#    for obj in animals:
#        obj.sound()
#        if (isinstance(obj, Dog)):
#            obj.walk()

# 다중상속 ####################################################
class Bus():
    def __init__(self):
        print("BUS()")
        #super(Bus, self).__init__()

class Moter():
    def __init__(self):
        print("MOTER()")
        #super(Moter, self).__init__()

class Battery():
    def __init__(self):
        print("BATTERY()")
        #super(Battery, self).__init__()

class ElectroicBus(Bus, Moter,Battery):
    def __init__(self):
        super().__init__()
        # super(ElectroicBus,self).__init__()

        # Bus.__init__(self)
        # Moter.__init__(self)
        # Battery.__init__(self)

# if __name__ == "__main__":
eb = ElectroicBus()






