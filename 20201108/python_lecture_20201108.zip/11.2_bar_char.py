import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_excel("./data/시군구별_이동건수_2001_2019.xlsx")
df = df.replace('-',0)

df_seoul = df.iloc[2]
seoul_labels = df_seoul.index[2:21]
seoul_means = df_seoul.values[2:21]

df_busan = df.iloc[3]
busan_means = df_busan.values[2:21]

labels = seoul_labels
men_means = seoul_means
women_means = busan_means

x = np.arange(len(labels))  # the label locations
width = 0.35  # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(x - width/2, men_means, width, label='Seoul')
rects2 = ax.bar(x + width/2, women_means, width, label='Busan')

# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('People')
ax.set_title('Seoul, Busan In/Out')
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.legend()


def autolabel(rects):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')


autolabel(rects1)
autolabel(rects2)

fig.tight_layout()

plt.show()