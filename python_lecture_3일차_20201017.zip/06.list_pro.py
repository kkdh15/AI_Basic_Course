#문제 - 피보나츠 수열
# 1 2 3 5 8 13 21 34 55... 100개 그리고 합
# pibo_list = []
# pibo_list.append(1)
# pibo_list.append(2)

# for i in range(0,8,1): #98 count
#     pibo_list.append(pibo_list[i]+pibo_list[i+1])
#     print(pibo_list)

# sum = 0 
# for element in pibo_list:# 1 2 3 5 8 13 21 34 55 89
#     print(element)
#     sum += element

# print("Total : %d" %sum)

#문제 lotto 6자리가 안 겹치도록 만드시오.(10/18 과제)
from random import *

lotto = [0,0,0,0,0,0]
for i in range(0,6,1):
    lotto[i] = randint(1,45) #1~45

print(lotto)
#[19, 26, 44, 31, 19, 25]
