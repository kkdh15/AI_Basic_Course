# 문제 - 약수 : 나누어 떨어지는 수 15 => 1 , 3, 5 , 15
# 15 => 1 ~ 15
# num = int(input("값 입력 : "))
# print("{}의 약수 : ".format(num), end="")
# for k in range (1,num+1,1):#1~15
#     if (num % k == 0) :#약수
#         print(k, end=", ")


# 문제 - 1 ~ 100 소수만 출력하시오. 소수 : 7 => 1, 7 나누어 떨어져야 함
# 소수
# count_sosu = 0
# for i in range(2,101,1):
#     count = 0
#     for j in range(1,i+1,1): # 5 : j = 1,2,3,4,5
#         if (i % j == 0):
#             count += 1

#     if(count == 2):
#         print(i, end = ", ")
#         count_sosu += 1

# print("\n소수의 갯수 : %d" %count_sosu)

# 문제 : 4x + 5y = 60, 경우의 수, 1<= x,y <=100
for x in range(1,101,1): #100
    for y in range(1,101,1): #100
        if((4 * x) + (5 * y)) == 60: #10000
            print ("( %d, %d )" %(x,y))

#문제 별찍기
# * 
# **
# ***
# ****
# *****

# for i in range(1,6,1):
#     for j in range(1,i+1,1):
#         print("*", end="")
#     print()

# for i in range(1,6,1):
#     print("*" * i)


# 문제
#     * 
#    **
#   ***
#  ****
# *****

# for i in range(5,0,-1):
#     for j in range(1,6,1):
#         if(i>j):
#             print(" ",end="")
#         else:
#             print("*",end="")
#     print()

# for i in range(4,-1,-1):
#     print(" " * i, end="")
#     print("*" * (5 -i))



# 문제 - 임의 값 2개를 입력받아 최대공약수, 최소공배수를 찾으시오
num1=int(input("임의값1 : "))
num2=int(input("임의값2 : "))

max = num1 if (num1 > num2) else num2
min = num1 if (num1 < num2) else num2

#최소공배수
for x in range(max, (num1*num2)+1, 1):
    if (x%num1 ==0)&(x%num2 ==0):
        l = x 
        break

#최대공약수
for y in range(1, min+1, 1):
    if (num1 % y == 0)&(num2 % y ==0):
        g = y

print("최소공배수 =", l)
print("최대공약수 =", g)






    


