# class
# class 대문자 
# class instance 구분

class Dog:
    #생성자 (construct)
    def __init__(self,name, age):
        self.name = name #속성(field)
        self.age = age

    def sit(self):
        print(f"{self.name}가 앉다")

    def run(self):
        print(f"{self.name}가 달리다")

    def roll(self):
        print(f"{self.name}가 구르다")

#instance 
my_dog = Dog("멍멍이", 2)
your_dog = Dog("곰돌이", 3)

#print("내 강아지는 {0}이고, {1}살 입니다.".format(my_dog.name, my_dog.age))
#print("너의 강아지는 {0}이고, {1}살 입니다.".format(your_dog.name, your_dog.age))


class Car:
    #속성
    maker = ''
    model = ''
    year = 0
    speed = 0

    def __init__(self, maker, model, year):
        self.maker = maker
        self.model = model
        self.year = year

    def set_maker(self ,maker):
        self.maker = maker

    def get_maker(self):
        return self.maker

    def print_info(self):
        print("{}, {}, {}".format(self.maker, self.model, self.year))


#문제 1
# Restaurant
# 생성자 : 식당이름,식당종류,식당개업연도
# 식당소개() describe_restaurant() :
# 식당메뉴소개() 매서드명 자유:
# 식당열기() 매서드명 자유 : 식당이 열렸습니다.
# 식당닫기() 매서드명 자유 : 식당이 닫혔습니다.

# 식당 1,2,3 개업
class Restaurant():
    foot_type = "프랑스요리" #class variable 전역변수 or 상수 개념으로 이해

    def __init__(self, name, foot_type, year):
        self.name = name          #instance variable 
        self.foot_type = foot_type
        self.year = year

    def describe(self):
        print("{}년에 개업한 {}입니다.".format(self.year, self.name))

    def menu(self):
        print("{}식당의 메뉴는 {}입니다.".format(self.name, self.foot_type))

    def open(self):
        print("식당이 열렸습니다.")

    def close(self):
        print("식당이 닫혔습니다.")

R1 = Restaurant("백반", "한정식", "2020")
R2 = Restaurant("중화반점", "중식", "2019")
R3 = Restaurant("돈라멘", "일식", "2018")

R1.describe()
R2.describe()
R3.describe()

R1.menu()
R2.menu()
R3.menu()

print(Restaurant.foot_type)
print(R1.foot_type)






