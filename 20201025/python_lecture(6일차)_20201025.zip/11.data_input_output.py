# def function(param):
#     print(param)

# function("***** hello world *****")

# #print(dir([1,2,3,4]))
# print(divmod(10,3)) # 3 1

# seasons = ['Spring', 'Summer', 'Fall', 'Winter']
# print(list(enumerate(seasons)))

# a = 10
# b = 20
# print(id(a), id(b))
# a = b
# print(id(a), id(b))

# file_object = open('C:/python_lecture/test.txt','w')
# file_object.write('hello yeodongbin')
# file_object.close()

# file_object = open('C:/python_lecture/test.txt','r')
# line = file_object.readline()
# print(line)
# file_object.close()

# with open('C:/python_lecture/test.txt','r') as file_object:
#     line = file_object.readline()
#     print(line)

# # list => file
# names = ['yeodongbin', 'mike', 'david']

# with open('C:/python_lecture/name.txt','w') as file_obj:
#     for name in names:
#         file_obj.write(name + '\n')
#     file_obj.writelines(names)
#     print("--- program write end ---")


# with open('C:/python_lecture/name.txt','r') as file_obj:
#     lines = file_obj.readlines()
#     print("type(lines) : {0}".format(type(lines)))
#     for line in lines:
#         print(line, end = '')
#     print("\n--- program read end ---")

#문제 name.txt -- 복사 --> name_copy.txt  
# 1 yeodongbin
# 2 mike
# 3 david
# 4 yeodongbin
# 5 mike
# 6 david

# names = []
# with open(r'C:/python_lecture/name.txt', 'r', encoding='utf-8') as file_obj:
#     names = file_obj.readlines()

# with open(r'C:/python_lecture/name_copy.txt', 'w', encoding='utf-8') as file_obj_copy:
#     for index, name in enumerate(names):
#         file_obj_copy.write(str(index+1) + '\t' + ord(name))
# 파일 encoding utf-8


# ## 파일 암호화
# # print(ord("여"))
# # print(chr(50668))

# # num = int(ord("여")) + 10 # 암호화 알고리즘
# # print(num)
# # print(chr(50678))

# # ## 파일 복호화 -10
# # print(chr(50678-10))


# #예제 암호화와 복호화
# inFp, outFp = None, None  #파일 Obj
# inStr, outStr = '', ''

# secu_num = 0 #암호화 알고리즘 핵심

# select = int(input("1: 암호화, 2: 복호화 // 번호를 선택해 주세요."))
# in_file_name = input("입력 파일명 저장 : ")
# out_file_name = input("저장 파일명 저장 : ")

# if (select == 1): 
#     secu_num = 100 #암호화
# elif (select == 2):
#     secu_num = -100 #복호화
# else :
#     print('선택되지 않았습니다')

# inFp = open('C:/python_lecture/'+in_file_name,'r', encoding='utf-8')
# inFp=  open('C:/Users/sorba/workspace/'+in_file_name,'r',encoding='utf-8')

# while True:
#     #yeodongbin =>  y e o d o n g b i n
#     in_str = inFp.readline()
#     if not in_str:
#         break

#     out_str = ''
#     #yeodongbin =>  y e o d o n g b i n => 0~9
#     for i in range(0, len(in_str)):
#         ch = in_str[i]  #char  ch = y
#         chNum = ord(ch) # y => 10000 
#         chNum = chNum + secu_num # 10100
#         ch2 = chr(chNum)
#         out_str = out_str + ch2 #문자열 만들기 " y + e  + o + d +"

#     outFp.write(out_str)

# outFp.close()
# inFp.close()

# print(f"{in_file_name} ---> {out_file_name} : 암호화 변환완료")
# print("%s ---> %s : 암호화 변환완료"%(in_file_name, out_file_name))

# print("--- program end ---")


#binery copy 
input_file = open("C:/python_lecture/npp.exe",'rb')
output_file = open("C:/python_lecture/npp_copy.exe",'wb')

while True:
    input_binery =input_file.read()
    if not input_binery:
        break
    output_file.write(input_binery)

input_file.close()
output_file.close()

print("end program")






