#starcraft
# SCV : worker
# hp
# mp
# attack(scv)
# move(x, y)
# mine(mineral)
# fix(scv)

class SCV:
    def __init__(self, num):
        self.__hp = 50  # 캡슐화 (외부 보이지 않는다.)
        self.__mp = 0
        self.scv_num = num
        self.x = 0
        self.y = 0

    #getter
    def get_mp(self):
        print("{}".format(self.__mp))
        return self.__mp

    #setter
    def set_mp(self, mp):
        self.__mp = mp
        print("{}".format(self.__mp))

    def move(self, x, y):
        self.x = x
        self.y = y

    def attack(self, scv):
        scv.__hp = scv.__hp - 10

    def fix(self, scv):
        scv.__hp = scv.__hp + 10

    def check(self):
        print(f"SCV({self.scv_num}) : ({self.__hp}, {self.__mp})")


scv1 = SCV(1)
scv1.check()

scv2 = SCV(2)
scv2.check()

scv1.attack(scv2)
scv1.check()
scv2.check()

scv1.fix(scv2)
scv1.check()
scv2.check()

#문제 - User 클래스
# - 캡슐화
# first_name
# last_name
# age
# height
# weight

# set_user(first_name, last_name)
# set_private(age, height, weight)
# describe(user)
# greet_user()
# => 안녕하세요. {이름} 입니다.

class User:
    def __init__(self):
        pass

    def set_user(self, first_name, last_name):
        self.__first_name = first_name
        self.__last_name = last_name

    def set_private(self, age, height, weight):
        self.__age = age
        self.__height = height
        self.__weight = weight

    def describe(self):
        print("first_name : {}\nlast_name : {}\nage : {}\nheight : {}\nweight : {}\n"
                .format(self.__first_name, self.__last_name, self.__age, 
                        self.__height, self.__weight))

    def greet_user(self):
        print("안녕하세요. {}{}입니다.".format(self.__first_name, self.__last_name))


user = User()
user.set_user("유", "소윤")
user.set_private(24, 180, 50)
user.describe()
user.greet_user()
